import axios, { AxiosError } from 'axios'
import {
  backendBaseUrl,
  documentFetchTimeoutMessage,
  healthCheckTimeout,
  pipelineStatusTimeout,
  popularLabelsDefaultLimit,
  searchLabelsDefaultLimit
} from '@/lib/constants'
import type { SupportedFileTypes } from '@/lib/fileTypes'
import { errorMessage } from '@/lib/utils'
import { decodeBase64Url } from '@/lib/base64url'
import { useSettingsStore } from '@/stores/settings'
import { useAuthStore } from '@/stores/state'
import { applyAiContentNoticeFlag } from '@/stores/aiContentNotice'
import { navigationService } from '@/services/navigation'
import { AuthenticationRequiredError, isAuthenticationRequiredError } from '@/api/errors'

// Types
export type LightragNodeType = {
  id: string
  labels: string[]
  properties: Record<string, any>
}

export type LightragEdgeType = {
  id: string
  source: string
  target: string
  type: string
  properties: Record<string, any>
}

export type LightragGraphType = {
  nodes: LightragNodeType[]
  edges: LightragEdgeType[]
}

export type LightragQueueStatus = {
  available: boolean
  queue_name?: string
  max_async?: number
  max_queue_size?: number
  queued?: number
  running?: number
  in_flight?: number
  worker_count?: number
  initialized?: boolean
  submitted_total?: number
  completed_total?: number
  failed_total?: number
  cancelled_total?: number
  rejected_total?: number
}

export type LightragRoleLLMConfig = {
  binding?: string | null
  model?: string | null
  host?: string | null
  max_async?: number
  timeout?: number
  has_model_kwargs?: boolean
  metadata?: Record<string, any>
}

export type LightragStatus = {
  status: 'healthy'
  working_directory: string
  input_directory: string
  configuration: {
    llm_binding: string
    llm_binding_host: string
    llm_model: string
    embedding_binding: string
    embedding_binding_host: string
    embedding_model: string
    kv_storage: string
    doc_status_storage: string
    graph_storage: string
    vector_storage: string
    workspace?: string
    storage_workspaces?: {
      kv_storage?: string | null
      doc_status_storage?: string | null
      graph_storage?: string | null
      vector_storage?: string | null
    }
    max_graph_nodes?: string
    enable_rerank?: boolean
    rerank_binding?: string | null
    rerank_model?: string | null
    rerank_binding_host?: string | null
    rerank_max_async?: number
    rerank_timeout?: number
    summary_language: string
    force_llm_summary_on_merge: boolean
    max_parallel_insert: number
    max_async: number
    llm_timeout?: number
    embedding_func_max_async: number
    embedding_batch_num: number
    embedding_timeout?: number
    cosine_threshold: number
    min_rerank_score: number
    related_chunk_number: number
    role_llm_config?: Record<string, LightragRoleLLMConfig>
    vlm_process_enable?: boolean
    parser_routing?: string
    mineru?: {
      endpoint: string
      api_mode: 'official' | 'local' | null
      options: {
        language?: string
        enable_table?: boolean
        enable_formula?: boolean
        model_version?: string
        is_ocr?: boolean
        local_backend?: string
        local_parse_method?: string
        local_image_analysis?: boolean
      }
    }
    docling?: {
      endpoint: string
      options: {
        do_ocr?: boolean
        force_ocr?: boolean
        ocr_engine?: string
        ocr_lang?: string
        do_formula_enrichment?: boolean
      }
    }
  }
  update_status?: Record<string, any>
  core_version?: string
  api_version?: string
  webui_available?: boolean
  /** Whether /docs, /redoc and /openapi.json are served. Absent on older
   * backends, which always expose them (see apiDocsCapability in state.ts). */
  api_docs_available?: boolean
  auth_mode?: 'enabled' | 'disabled'
  server_mode?: 'uvicorn' | 'gunicorn'
  workers?: number
  pipeline_busy: boolean
  pipeline_active?: boolean
  pipeline_scanning?: boolean
  pipeline_destructive_busy?: boolean
  pipeline_pending_enqueues?: number
  llm_queue_status?: Record<string, LightragQueueStatus>
  embedding_queue_status?: LightragQueueStatus
  rerank_queue_status?: LightragQueueStatus
  keyed_locks?: {
    process_id: number
    cleanup_performed: {
      mp_cleaned: number
      async_cleaned: number
    }
    current_status: {
      total_mp_locks: number
      pending_mp_cleanup: number
      total_async_locks: number
      pending_async_cleanup: number
    }
  }
  webui_title?: string
  webui_description?: string
  /** Whether answers are labelled as AI-generated in the query UIs. */
  ai_content_notice_enabled?: boolean
}

/**
 * Specifies the retrieval mode:
 * - "naive": Performs a basic search without advanced techniques.
 * - "local": Focuses on context-dependent information.
 * - "global": Utilizes global knowledge.
 * - "hybrid": Combines local and global retrieval methods.
 * - "mix": Integrates knowledge graph and vector retrieval.
 * - "bypass": Bypasses knowledge retrieval and directly uses the LLM.
 */
export type QueryMode = 'naive' | 'local' | 'global' | 'hybrid' | 'mix' | 'bypass'

export type Message = {
  role: 'user' | 'assistant' | 'system'
  content: string
  thinkingContent?: string
  displayContent?: string
  thinkingTime?: number | null
  responseTime?: number | null
  firstTokenTime?: number | null
}

export type QueryRequest = {
  query: string
  /** Specifies the retrieval mode. */
  mode: QueryMode
  /** If True, only returns the retrieved context without generating a response. */
  only_need_context?: boolean
  /** If True, only returns the generated prompt without producing a response. */
  only_need_prompt?: boolean
  /** Defines the response format. Examples: 'Multiple Paragraphs', 'Single Paragraph', 'Bullet Points'. */
  response_type?: string
  /** If True, enables streaming output for real-time responses. */
  stream?: boolean
  /** Number of top items to retrieve. Represents entities in 'local' mode and relationships in 'global' mode. */
  top_k?: number
  /** Maximum number of text chunks to retrieve and keep after reranking. */
  chunk_top_k?: number
  /** Maximum number of tokens allocated for entity context in unified token control system. */
  max_entity_tokens?: number
  /** Maximum number of tokens allocated for relationship context in unified token control system. */
  max_relation_tokens?: number
  /** Maximum total tokens budget for the entire query context (entities + relations + chunks + system prompt). */
  max_total_tokens?: number
  /**
   * Stores past conversation history to maintain context.
   * Format: [{"role": "user/assistant", "content": "message"}].
   */
  conversation_history?: Message[]
  /** Number of complete conversation turns (user-assistant pairs) to consider in the response context. */
  history_turns?: number
  /**
   * Additional instructions for the LLM, injected into the "Additional
   * Instructions" section of the answer prompt. Does not affect retrieval.
   * The server may prepend a global prefix; see disable_user_prompt_prefix.
   */
  user_prompt?: string
  /**
   * If true, the server-side global prompt prefix is not prepended to
   * user_prompt, leaving this client in full control of the final instruction
   * text. The prefix itself is server configuration and cannot be read or
   * replaced from here. Default: false.
   */
  disable_user_prompt_prefix?: boolean
  /** Enable reranking for retrieved text chunks. If True but no rerank model is configured, a warning will be issued. Default is True. */
  enable_rerank?: boolean
  /** If True, emits retrieval progress events and a final response-time metadata line (streaming only). Default: false. */
  include_progress?: boolean
}

export type QueryResponse = {
  response: string
  response_time?: number
  /**
   * Whether the answering LLM actually wrote this response. False for text a
   * query path produced without calling it — the canned no-context reply and
   * the only_need_context / only_need_prompt debug output. Absent on servers
   * older than the field.
   */
  llm_generated?: boolean
}

export type EntityUpdateResponse = {
  status: string
  message: string
  data: Record<string, any>
  operation_summary?: {
    merged: boolean
    merge_status: 'success' | 'failed' | 'not_attempted'
    merge_error: string | null
    operation_status: 'success' | 'partial_success' | 'failure'
    target_entity: string | null
    final_entity?: string | null
    renamed?: boolean
  }
}

export type DocActionResponse = {
  status: 'success' | 'partial_success' | 'failure'
  message: string
  track_id?: string
}

export type ScanResponse = {
  status: 'scanning_started' | 'scanning_skipped_pipeline_busy'
  message: string
  track_id: string
}

export type ReprocessFailedResponse = {
  status: 'reprocessing_started'
  message: string
  track_id: string
}

export type DeleteDocResponse = {
  status: 'deletion_started' | 'busy' | 'not_allowed'
  message: string
  doc_id: string
}

export type DocStatus =
  | 'pending'
  | 'parsing'
  | 'analyzing'
  | 'processing'
  | 'preprocessed'
  | 'processed'
  | 'failed'

export type DocStatusResponse = {
  id: string
  content_summary: string
  content_length: number
  status: DocStatus
  created_at: string
  updated_at: string
  track_id?: string
  chunks_count?: number
  error_msg?: string
  metadata?: Record<string, any>
  file_path: string
}

export type TrackStatusResponse = {
  track_id: string
  documents: DocStatusResponse[]
  total_count: number
  status_summary: Record<string, number>
}

export type DocumentsRequest = {
  status_filter?: DocStatus | null
  status_filters?: DocStatus[] | null
  page: number
  page_size: number
  sort_field: 'created_at' | 'updated_at' | 'id' | 'file_path'
  sort_direction: 'asc' | 'desc'
}

export type PaginationInfo = {
  page: number
  page_size: number
  total_count: number
  total_pages: number
  has_next: boolean
  has_prev: boolean
}

export type PaginatedDocsResponse = {
  documents: DocStatusResponse[]
  pagination: PaginationInfo
  status_counts: Record<string, number>
}

export type AuthStatusResponse = {
  auth_configured: boolean
  access_token?: string
  token_type?: string
  auth_mode?: 'enabled' | 'disabled'
  message?: string
  core_version?: string
  api_version?: string
  webui_title?: string
  webui_description?: string
  /** Whether answers are labelled as AI-generated in the query UIs. */
  ai_content_notice_enabled?: boolean
}

export type PipelineStatusResponse = {
  busy: boolean
  job_name: string
  job_start?: string
  docs: number
  batchs: number
  cur_batch: number
  cancellation_requested?: boolean
  latest_message: string
  history_messages?: string[]
  update_status?: Record<string, any>
}

export type LoginResponse = {
  access_token: string
  token_type: string
  auth_mode?: 'enabled' | 'disabled'  // Authentication mode identifier
  message?: string                    // Optional message
  core_version?: string
  api_version?: string
  webui_title?: string
  webui_description?: string
  /** Whether answers are labelled as AI-generated in the query UIs. */
  ai_content_notice_enabled?: boolean
}

export const InvalidApiKeyError = 'Invalid API Key'
export const RequireApiKeError = 'API Key required'

// Axios instance
const axiosInstance = axios.create({
  baseURL: backendBaseUrl,
  headers: {
    'Content-Type': 'application/json'
  }
})

// ========== Token Management ==========
// Prevent multiple requests from triggering token refresh simultaneously
let isRefreshingGuestToken = false;
let refreshTokenPromise: Promise<string> | null = null;

// Silent refresh for guest token
const silentRefreshGuestToken = async (): Promise<string> => {
  // If already refreshing, return the same Promise
  if (isRefreshingGuestToken && refreshTokenPromise) {
    return refreshTokenPromise;
  }

  isRefreshingGuestToken = true;
  refreshTokenPromise = (async () => {
    try {
      // Call /auth-status to get new guest token
      const response = await axios.get('/auth-status', {
        baseURL: backendBaseUrl,
        // This request must skip the interceptor to avoid adding expired token
        headers: { 'X-Skip-Interceptor': 'true' }
      });

      applyAiContentNoticeFlag(response.data?.ai_content_notice_enabled);

      if (response.data.access_token && !response.data.auth_configured) {
        const newToken = response.data.access_token;
        // Update localStorage
        localStorage.setItem('LIGHTRAG-API-TOKEN', newToken);
        // Update auth state
        useAuthStore.getState().login(
          newToken,
          true,
          response.data.core_version,
          response.data.api_version,
          response.data.webui_title || null,
          response.data.webui_description || null
        );
        return newToken;
      } else {
        throw new Error('Failed to get guest token');
      }
    } finally {
      isRefreshingGuestToken = false;
      refreshTokenPromise = null;
    }
  })();

  return refreshTokenPromise;
};

// Interceptor: add api key and check authentication
axiosInstance.interceptors.request.use((config) => {
  // Skip interceptor for token refresh requests
  if (config.headers['X-Skip-Interceptor']) {
    delete config.headers['X-Skip-Interceptor'];
    return config;
  }

  const apiKey = useSettingsStore.getState().apiKey
  const token = localStorage.getItem('LIGHTRAG-API-TOKEN');

  // Always include token if it exists, regardless of path
  if (token) {
    config.headers['Authorization'] = `Bearer ${token}`
  }
  if (apiKey) {
    config.headers['X-API-Key'] = apiKey
  }
  return config
})

// Interceptor：handle token renewal and authentication errors
/**
 * An HTTP error surfaced by the response interceptor.
 *
 * The status is carried as a property, not only inside the message: callers
 * branch on it (e.g. the document list treats a 4xx as a permanent client
 * error that must not trip its circuit breaker), and a plain Error left them
 * unable to tell a 404 from a network failure.
 */
export type HttpRequestError = Error & { status?: number }

export const toHttpRequestError = (
  status: number,
  statusText: string,
  data: unknown,
  url?: string
): HttpRequestError => {
  const error = new Error(
    `${status} ${statusText}\n${JSON.stringify(data)}\n${url}`
  ) as HttpRequestError
  error.status = status
  return error
}

axiosInstance.interceptors.response.use(
  (response) => {
    // ========== Check for new token from backend ==========
    const newToken = response.headers['x-new-token'];
    if (newToken) {
      localStorage.setItem('LIGHTRAG-API-TOKEN', newToken);

      // Optional: log in development mode
      if (import.meta.env.DEV) {
        console.log('[Auth] Token auto-renewed by backend');
      }

      // Update auth state with renewal tracking.
      //
      // The payload MUST go through decodeBase64Url, like every other reader
      // of a JWT here (stores/state.ts, lib/loginIdentity.ts). Bare `atob`
      // rejects the `-`/`_` alphabet, and the catch below swallows that: the
      // renewed token is already in localStorage by then, so the session
      // would carry the NEW token while `lastTokenRenewal` and
      // `tokenExpiresAt` still described the OLD one.
      try {
        const decodedPayload = decodeBase64Url(newToken.split('.')[1] ?? '');
        const payload = decodedPayload === null ? {} : JSON.parse(decodedPayload);
        const authStore = useAuthStore.getState();
        if (authStore.isAuthenticated) {
          // Track token renewal time and expiration
          const renewalTime = Date.now();
          const expiresAt = payload.exp ? payload.exp * 1000 : 0;
          authStore.setTokenRenewal(renewalTime, expiresAt);

          // Update username (usually unchanged, but just in case)
          const newUsername = payload.sub;
          if (newUsername && newUsername !== authStore.username) {
            // Need to add setUsername method or just update via login
            // For now, we'll skip username update as it's rare
          }
        }
      } catch (error) {
        console.warn('[Auth] Failed to parse renewed token:', error);
      }
    }
    // ========== End of token renewal check ==========

    return response;
  },
  async (error: AxiosError) => {
    if (error.response) {
      if (error.response?.status === 401) {
        const originalRequest = error.config;

        // 1. For login API, throw error directly
        if (originalRequest?.url?.includes('/login')) {
          throw error;
        }

        // 2. Prevent infinite retry
        if (originalRequest && (originalRequest as any)._retry) {
          navigationService.navigateToUnauthenticated();
          return Promise.reject(new AuthenticationRequiredError());
        }

        // 3. Check if in guest mode
        const authStore = useAuthStore.getState();
        const currentToken = localStorage.getItem('LIGHTRAG-API-TOKEN');
        const isGuest = currentToken && authStore.isGuestMode;

        // 4. Guest mode: silent refresh and retry
        if (isGuest && originalRequest) {
          try {
            const newToken = await silentRefreshGuestToken();

            // Mark as retried to prevent infinite loop
            (originalRequest as any)._retry = true;

            // Update token in request headers
            originalRequest.headers['Authorization'] = `Bearer ${newToken}`;

            // Retry original request
            return axiosInstance(originalRequest);
          } catch (refreshError) {
            console.error('Failed to refresh guest token:', refreshError);
            // Refresh failed, navigate to login
            navigationService.navigateToUnauthenticated();
            return Promise.reject(
              new AuthenticationRequiredError('Failed to refresh authentication', {
                cause: refreshError,
              })
            );
          }
        }

        // 5. Non-guest mode: navigate to login page
        navigationService.navigateToUnauthenticated();
        return Promise.reject(new AuthenticationRequiredError());
      }
      throw toHttpRequestError(
        error.response.status,
        error.response.statusText,
        error.response.data,
        error.config?.url
      )
    }
    throw error
  }
)

// API methods
export const queryGraphs = async (
  label: string,
  maxDepth: number,
  maxNodes: number
): Promise<LightragGraphType> => {
  const response = await axiosInstance.get(`/graphs?label=${encodeURIComponent(label)}&max_depth=${maxDepth}&max_nodes=${maxNodes}`)
  return response.data
}

export const getGraphLabels = async (): Promise<string[]> => {
  const response = await axiosInstance.get('/graph/label/list')
  return response.data
}

export const getPopularLabels = async (limit: number = popularLabelsDefaultLimit): Promise<string[]> => {
  const response = await axiosInstance.get(`/graph/label/popular?limit=${limit}`)
  return response.data
}

export const searchLabels = async (query: string, limit: number = searchLabelsDefaultLimit): Promise<string[]> => {
  const response = await axiosInstance.get(`/graph/label/search?q=${encodeURIComponent(query)}&limit=${limit}`)
  return response.data
}

export const checkHealth = async (): Promise<
  LightragStatus | { status: 'error'; message: string }
> => {
  try {
    // Explicit timeout: the axios instance sets none, so a backend whose
    // event loop is blocked would leave this request hanging and the health
    // state would neither succeed nor fail. Kept below healthCheckInterval
    // so probes cannot pile up.
    const response = await axiosInstance.get('/health', {
      timeout: healthCheckTimeout * 1000
    })
    return response.data
  } catch (error) {
    return {
      status: 'error',
      message: errorMessage(error)
    }
  }
}

/**
 * Probe whether the caller's credentials satisfy the API's combined auth.
 * /health CANNOT serve this purpose: it sits on the default whitelist and
 * deliberately answers "healthy" to unauthenticated callers, so it never
 * distinguishes valid, invalid and missing API keys. /auth/verify always
 * runs the combined dependency — a missing or wrong X-API-Key REJECTS with
 * the standard 403 detail ("API Key required" / "Invalid API Key"), which
 * the axios interceptor surfaces in the thrown error's message.
 */
export const verifyCredentials = async (): Promise<void> => {
  await axiosInstance.get('/auth/verify')
}

export const getSupportedFileTypes = async (signal?: AbortSignal): Promise<SupportedFileTypes> => {
  const response = await axiosInstance.get('/documents/supported_file_types', { signal })
  return response.data
}

export const scanNewDocuments = async (): Promise<ScanResponse> => {
  const response = await axiosInstance.post('/documents/scan')
  return response.data
}

export const reprocessFailedDocuments = async (): Promise<ReprocessFailedResponse> => {
  const response = await axiosInstance.post('/documents/reprocess_failed')
  return response.data
}

export const queryText = async (
  request: QueryRequest,
  signal?: AbortSignal
): Promise<QueryResponse> => {
  const response = await axiosInstance.post('/query', request, { signal })
  return response.data
}

/**
 * True when an error originates from the user aborting the request (Stop
 * button) rather than a real failure. Used to suppress error rendering and any
 * auth-failure side effects (e.g. redirecting to login) on user cancellation.
 */
export const isUserAbortError = (
  signal: AbortSignal | undefined,
  error: unknown
): boolean => Boolean(signal?.aborted) || (error as Error)?.name === 'AbortError'

/**
 * Read an NDJSON (application/x-ndjson) stream from a fetch Response body
 * and dispatch each parsed line to ``onChunk`` / ``onError``.
 *
 * Extracted from ``queryTextStream`` so the normal path and the guest-token
 * retry path share the same parsing logic without duplication.
 */
async function _readNdjsonStream(
  response: Response,
  onChunk: (chunk: string) => void,
  onError: ((error: string) => void) | undefined,
  onResponseTime?: (seconds: number) => void,
  onProgress?: (event: string) => void,
  onLlmGenerated?: (llmGenerated: boolean) => void
): Promise<void> {
  if (!response.body) {
    throw new Error('Response body is null');
  }

  // One dispatcher for both readers below (the loop and the trailing buffer).
  // `llm_generated` is checked FIRST and separately: the server carries it on
  // the SAME line as a complete (non-streamed) response, and the caller must
  // know what the content is before the content arrives.
  const dispatch = (parsed: any): void => {
    if (typeof parsed.llm_generated === 'boolean') {
      onLlmGenerated?.(parsed.llm_generated);
    }
    if (parsed.response) {
      onChunk(parsed.response);
    } else if (parsed.error) {
      onError?.(parsed.error);
    } else if (parsed.response_time !== undefined && onResponseTime) {
      onResponseTime(parsed.response_time);
    } else if (parsed.progress && onProgress) {
      onProgress(parsed.progress);
    }
    // references-only lines are silently consumed —
    // the caller only cares about response chunks and errors.
  };

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });

      // Process complete lines (NDJSON)
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed) continue;

        try {
          dispatch(JSON.parse(trimmed));
        } catch {
          // Truncated or malformed JSON — log and skip the line so one
          // bad line does not kill the whole stream.
          console.warn('Failed to parse NDJSON line:', trimmed.substring(0, 120));
        }
      }
    }
  } finally {
    // Always release the reader lock, even on abort
    try {
      reader.releaseLock();
    } catch {
      // Already released or never acquired
    }
  }

  // Process any remaining data in the buffer after the stream ends
  if (buffer.trim()) {
    try {
      dispatch(JSON.parse(buffer));
    } catch {
      console.warn('Failed to parse final NDJSON buffer:', buffer.substring(0, 120));
      onError?.(
        'Response stream ended with incomplete data — the response may be truncated.'
      );
    }
  }
}

/**
 * Build auth headers for the streaming fetch request.
 */
function _buildStreamHeaders(): HeadersInit {
  const apiKey = useSettingsStore.getState().apiKey;
  const token = localStorage.getItem('LIGHTRAG-API-TOKEN');
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    Accept: 'application/x-ndjson',
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  if (apiKey) {
    headers['X-API-Key'] = apiKey;
  }
  return headers;
}

/**
 * Classify a fetch error and produce a user-friendly message for
 * ``onError``, or ``null`` when the error should be silently swallowed
 * (e.g. user-initiated abort).
 */
function _classifyStreamError(
  error: unknown,
  signal: AbortSignal | undefined
): string | null {
  if (isUserAbortError(signal, error)) {
    return null; // Stop button — exit silently
  }

  const message = errorMessage(error);

  const statusCodeMatch = message.match(/^(\d{3})\s/);
  if (statusCodeMatch) {
    const statusCode = parseInt(statusCodeMatch[1], 10);
    switch (statusCode) {
      case 403:
        // A 403 raised by the API-key check must KEEP that detail: the
        // workspace entry recognizes these messages to re-probe credentials
        // and reopen its API-key dialog, which is the only way back in after
        // a key is rotated (and streaming is the default query mode, so
        // flattening them here disabled that path entirely). Unrelated 403s
        // keep the generic wording.
        if (message.includes(InvalidApiKeyError)) {
          return `${InvalidApiKeyError} (403 Forbidden)`;
        }
        if (message.includes(RequireApiKeError)) {
          return `${RequireApiKeError} (403 Forbidden)`;
        }
        return 'You do not have permission to access this resource (403 Forbidden)';
      case 404:
        return 'The requested resource does not exist (404 Not Found)';
      case 429:
        return 'Too many requests, please try again later (429 Too Many Requests)';
      case 500:
      case 502:
      case 503:
      case 504:
        return `Server error, please try again later (${statusCode})`;
      default:
        return message;
    }
  }

  if (
    message.includes('NetworkError') ||
    message.includes('Failed to fetch') ||
    message.includes('Network request failed')
  ) {
    return 'Network connection error, please check your internet connection';
  }

  if (message.includes('Error parsing') || message.includes('SyntaxError')) {
    return 'Error processing response data';
  }

  return message;
}

/**
 * Format a non-ok streaming ``Response`` into the canonical error string that
 * ``_classifyStreamError`` understands (``"<status> <statusText>\n{...}\n<url>"``)
 * and throw it. Always throws — the return type is ``never``.
 *
 * Shared by the first response and the refreshed-retry response so that an
 * HTTP error (403/429/5xx, …) is classified identically on both paths.
 */
async function _throwStreamHttpError(response: Response): Promise<never> {
  let errorBody = 'Unknown error';
  try {
    errorBody = await response.text();
  } catch {
    /* ignore */
  }
  throw new Error(
    `${response.status} ${response.statusText}\n${JSON.stringify({ error: errorBody })}\n${backendBaseUrl}/query/stream`
  );
}

export const queryTextStream = async (
  request: QueryRequest,
  onChunk: (chunk: string) => void,
  onError?: (error: string) => void,
  signal?: AbortSignal,
  onResponseTime?: (seconds: number) => void,
  onProgress?: (event: string) => void,
  // Reports the server's verdict on whether the answering LLM wrote the
  // content of a complete (non-streamed) response line. Streamed chunks carry
  // no flag — they always come from the LLM.
  onLlmGenerated?: (llmGenerated: boolean) => void
) => {
  const headers = _buildStreamHeaders();

  try {
    const response = await fetch(`${backendBaseUrl}/query/stream`, {
      method: 'POST',
      headers,
      body: JSON.stringify(request),
      signal,
    });

    // The response whose body we ultimately read — replaced by the retry
    // response when a guest token is silently refreshed below.
    let activeResponse = response;

    if (!response.ok) {
      // --- 401 guest-token retry -------------------------------------------
      if (response.status === 401) {
        const currentToken = localStorage.getItem('LIGHTRAG-API-TOKEN');
        const isGuest =
          currentToken && useAuthStore.getState().isGuestMode;

        if (isGuest) {
          // Only the token refresh + retry fetch are guarded here: a failure
          // of the refresh itself (or a user abort) is an auth problem and
          // routes to login. The retried HTTP *response*, however, is handled
          // with the same logic as the first response below, so a 403/429/5xx
          // on retry is classified by the outer catch rather than mislabelled
          // as an auth-refresh failure.
          let retryResponse: Response;
          try {
            const newToken = await silentRefreshGuestToken();
            const retryHeaders: Record<string, string> = { ...(headers as Record<string, string>) };
            retryHeaders['Authorization'] = `Bearer ${newToken}`;

            retryResponse = await fetch(`${backendBaseUrl}/query/stream`, {
              method: 'POST',
              headers: retryHeaders,
              body: JSON.stringify(request),
              signal,
            });
          } catch (refreshError) {
            if (isUserAbortError(signal, refreshError)) {
              return;
            }
            console.error(
              'Failed to refresh guest token for streaming:',
              refreshError
            );
            navigationService.navigateToUnauthenticated();
            throw new AuthenticationRequiredError('Failed to refresh authentication', {
              cause: refreshError,
            });
          }

          if (!retryResponse.ok) {
            if (retryResponse.status === 401) {
              // Refreshed token still rejected → genuine auth failure
              navigationService.navigateToUnauthenticated();
              throw new AuthenticationRequiredError();
            }
            // Non-auth HTTP error on retry → classify like the first response
            await _throwStreamHttpError(retryResponse);
          }

          activeResponse = retryResponse;
        } else {
          // Non-guest 401 → login
          navigationService.navigateToUnauthenticated();
          throw new AuthenticationRequiredError();
        }
      } else {
        // --- Other HTTP errors ---------------------------------------------
        await _throwStreamHttpError(response);
      }
    }

    // --- Read the NDJSON stream (happy path or refreshed retry) ------------
    await _readNdjsonStream(
      activeResponse,
      onChunk,
      onError,
      onResponseTime,
      onProgress,
      onLlmGenerated
    );
  } catch (error) {
    // Auth termination is NOT an answer failure: navigation to the entry's
    // unauthenticated route already happened above. Rethrow the typed error
    // so the query session ends quietly instead of rendering it as an
    // assistant error via onError.
    if (isAuthenticationRequiredError(error)) {
      throw error;
    }
    const classified = _classifyStreamError(error, signal);
    if (classified === null) {
      return; // User abort — silent exit
    }
    console.error('Stream request error:', classified);
    onError?.(classified);
  }
};

export const insertText = async (text: string): Promise<DocActionResponse> => {
  const response = await axiosInstance.post('/documents/text', { text })
  return response.data
}

export const insertTexts = async (texts: string[]): Promise<DocActionResponse> => {
  const response = await axiosInstance.post('/documents/texts', { texts })
  return response.data
}

export const uploadDocument = async (
  file: File,
  onUploadProgress?: (percentCompleted: number) => void
): Promise<DocActionResponse> => {
  const formData = new FormData()
  formData.append('file', file)

  const response = await axiosInstance.post('/documents/upload', formData, {
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    // prettier-ignore
    onUploadProgress:
      onUploadProgress !== undefined
        ? (progressEvent) => {
          const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total!)
          onUploadProgress(percentCompleted)
        }
        : undefined
  })
  return response.data
}

export const batchUploadDocuments = async (
  files: File[],
  onUploadProgress?: (fileName: string, percentCompleted: number) => void
): Promise<DocActionResponse[]> => {
  return await Promise.all(
    files.map(async (file) => {
      return await uploadDocument(file, (percentCompleted) => {
        onUploadProgress?.(file.name, percentCompleted)
      })
    })
  )
}

export const clearDocuments = async (): Promise<DocActionResponse> => {
  const response = await axiosInstance.delete('/documents')
  return response.data
}

export const clearCache = async (): Promise<{
  status: 'success' | 'fail'
  message: string
}> => {
  const response = await axiosInstance.post('/documents/clear_cache', {})
  return response.data
}

export const deleteDocuments = async (
  docIds: string[],
  deleteFile: boolean = false,
  deleteLLMCache: boolean = false
): Promise<DeleteDocResponse> => {
  const response = await axiosInstance.delete('/documents/delete_document', {
    data: { doc_ids: docIds, delete_file: deleteFile, delete_llm_cache: deleteLLMCache }
  })
  return response.data
}

export const getAuthStatus = async (): Promise<AuthStatusResponse> => {
  try {
    // Add a timeout to the request to prevent hanging
    const response = await axiosInstance.get('/auth-status', {
      timeout: 5000, // 5 second timeout
      headers: {
        'Accept': 'application/json' // Explicitly request JSON
      }
    });

    // Check if response is HTML (which indicates a redirect or wrong endpoint)
    const contentTypeHeader = response.headers['content-type'];
    const contentType = typeof contentTypeHeader === 'string' ? contentTypeHeader : '';
    if (contentType.includes('text/html')) {
      console.warn('Received HTML response instead of JSON for auth-status endpoint');
      return {
        auth_configured: true,
        auth_mode: 'enabled'
      };
    }

    // Deployment display configuration the caller never looks at: adopted here,
    // once, before the validation below picks one of its several return shapes
    // (this is the request BOTH entries make at boot, so it is the one place
    // that covers the admin shell, the login page and the workspace entry).
    applyAiContentNoticeFlag(response.data?.ai_content_notice_enabled);

    // Strict validation of the response data
    if (response.data &&
        typeof response.data === 'object' &&
        'auth_configured' in response.data &&
        typeof response.data.auth_configured === 'boolean') {

      // For unconfigured auth, ensure we have an access token
      if (!response.data.auth_configured) {
        if (response.data.access_token && typeof response.data.access_token === 'string') {
          return response.data;
        } else {
          console.warn('Auth not configured but no valid access token provided');
        }
      } else {
        // For configured auth, just return the data
        return response.data;
      }
    }

    // If response data is invalid but we got a response, log it
    console.warn('Received invalid auth status response:', response.data);

    // Default to auth configured if response is invalid
    return {
      auth_configured: true,
      auth_mode: 'enabled'
    };
  } catch (error) {
    // If the request fails, assume authentication is configured
    console.error('Failed to get auth status:', errorMessage(error));
    return {
      auth_configured: true,
      auth_mode: 'enabled'
    };
  }
}

export const getPipelineStatus = async (): Promise<PipelineStatusResponse> => {
  const response = await axiosInstance.get('/documents/pipeline_status', {
    timeout: pipelineStatusTimeout * 1000
  })
  return response.data
}

export const cancelPipeline = async (): Promise<{
  status: 'cancellation_requested' | 'not_busy'
  message: string
}> => {
  const response = await axiosInstance.post('/documents/cancel_pipeline')
  return response.data
}

export const loginToServer = async (username: string, password: string): Promise<LoginResponse> => {
  const formData = new URLSearchParams();
  formData.append('username', username);
  formData.append('password', password);
  formData.append('grant_type', 'password');

  const response = await axiosInstance.post('/login', formData, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  });

  applyAiContentNoticeFlag(response.data?.ai_content_notice_enabled);

  return response.data;
}

/**
 * Updates an entity's properties in the knowledge graph
 * @param entityName The name of the entity to update
 * @param updatedData Dictionary containing updated attributes
 * @param allowRename Whether to allow renaming the entity (default: false)
 * @param allowMerge Whether to merge into an existing entity when renaming to a duplicate name
 * @returns Promise with the updated entity information
 */
export const updateEntity = async (
  entityName: string,
  updatedData: Record<string, any>,
  allowRename: boolean = false,
  allowMerge: boolean = false
): Promise<EntityUpdateResponse> => {
  const response = await axiosInstance.post('/graph/entity/edit', {
    entity_name: entityName,
    updated_data: updatedData,
    allow_rename: allowRename,
    allow_merge: allowMerge
  })
  return response.data
}

/**
 * Updates a relation's properties in the knowledge graph
 * @param sourceEntity The source entity name
 * @param targetEntity The target entity name
 * @param updatedData Dictionary containing updated attributes
 * @returns Promise with the updated relation information
 */
export const updateRelation = async (
  sourceEntity: string,
  targetEntity: string,
  updatedData: Record<string, any>
): Promise<DocActionResponse> => {
  const response = await axiosInstance.post('/graph/relation/edit', {
    source_id: sourceEntity,
    target_id: targetEntity,
    updated_data: updatedData
  })
  return response.data
}

/**
 * Checks if an entity name already exists in the knowledge graph
 * @param entityName The entity name to check
 * @returns Promise with boolean indicating if the entity exists
 */
export const checkEntityNameExists = async (entityName: string): Promise<boolean> => {
  try {
    const response = await axiosInstance.get(`/graph/entity/exists?name=${encodeURIComponent(entityName)}`)
    return response.data.exists
  } catch (error) {
    console.error('Error checking entity name:', error)
    return false
  }
}

/**
 * Get the processing status of documents by tracking ID
 * @param trackId The tracking ID returned from upload, text, or texts endpoints
 * @returns Promise with the track status response containing documents and summary
 */
export const getTrackStatus = async (trackId: string): Promise<TrackStatusResponse> => {
  const response = await axiosInstance.get(`/documents/track_status/${encodeURIComponent(trackId)}`)
  return response.data
}

type InFlightPaginatedDocumentRequest = {
  controller: AbortController
  promise: Promise<PaginatedDocsResponse>
  subscriberCount: number
}

const getPaginatedDocumentsRequestKey = (request: DocumentsRequest): string =>
  JSON.stringify(request)

// Deduplicate in-flight paginated document requests with identical parameters.
// This prevents duplicate backend calls caused by overlapping timers/effects or
// React StrictMode double-mount behavior in development.
const inFlightPaginatedDocumentRequests = new Map<
  string,
  InFlightPaginatedDocumentRequest
>()

const releasePaginatedDocumentSubscriber = (
  requestKey: string,
  requestEntry: InFlightPaginatedDocumentRequest,
  abortIfLastSubscriber: boolean
): void => {
  requestEntry.subscriberCount = Math.max(0, requestEntry.subscriberCount - 1)

  if (requestEntry.subscriberCount !== 0) {
    return
  }

  if (inFlightPaginatedDocumentRequests.get(requestKey) === requestEntry) {
    inFlightPaginatedDocumentRequests.delete(requestKey)
  }

  if (abortIfLastSubscriber) {
    requestEntry.controller.abort()
  }
}

const subscribeToPaginatedDocumentsRequest = (
  request: DocumentsRequest
): {
  requestKey: string
  requestEntry: InFlightPaginatedDocumentRequest
  release: (abortIfLastSubscriber: boolean) => void
} => {
  const requestKey = getPaginatedDocumentsRequestKey(request)
  let requestEntry = inFlightPaginatedDocumentRequests.get(requestKey)

  if (!requestEntry) {
    const controller = new AbortController()
    requestEntry = {
      controller,
      subscriberCount: 0,
      promise: paginatedDocumentsPost(request, controller)
        .finally(() => {
          if (inFlightPaginatedDocumentRequests.get(requestKey) === requestEntry) {
            inFlightPaginatedDocumentRequests.delete(requestKey)
          }
        })
    }
    inFlightPaginatedDocumentRequests.set(requestKey, requestEntry)
  }

  requestEntry.subscriberCount += 1

  let released = false
  const release = (abortIfLastSubscriber: boolean): void => {
    if (released) {
      return
    }
    released = true
    releasePaginatedDocumentSubscriber(
      requestKey,
      requestEntry,
      abortIfLastSubscriber
    )
  }

  return {
    requestKey,
    requestEntry,
    release
  }
}

const defaultPaginatedDocumentsPost = async (
  request: DocumentsRequest,
  controller: AbortController
): Promise<PaginatedDocsResponse> => {
  const response = await axiosInstance.post('/documents/paginated', request, {
    signal: controller.signal
  })
  return response.data
}

let paginatedDocumentsPost = defaultPaginatedDocumentsPost

export const abortDocumentsPaginated = (request: DocumentsRequest): void => {
  const requestKey = getPaginatedDocumentsRequestKey(request)
  const inFlightRequest = inFlightPaginatedDocumentRequests.get(requestKey)

  if (!inFlightRequest) {
    return
  }

  inFlightPaginatedDocumentRequests.delete(requestKey)
  inFlightRequest.controller.abort()
}

export const __resetPaginatedDocumentRequestsForTests = (): void => {
  for (const { controller } of inFlightPaginatedDocumentRequests.values()) {
    controller.abort()
  }
  inFlightPaginatedDocumentRequests.clear()
  paginatedDocumentsPost = defaultPaginatedDocumentsPost
}

export const __setPaginatedDocumentsPostForTests = (
  post: typeof defaultPaginatedDocumentsPost
): void => {
  paginatedDocumentsPost = post
}

/**
 * Swap the axios adapter so a test can drive a response (or an HTTP failure)
 * through the real request/response interceptors. Pass undefined to restore.
 */
export const __setAxiosAdapterForTests = (adapter: any): void => {
  axiosInstance.defaults.adapter = adapter
}

/**
 * Get documents with pagination support
 * @param request The pagination request parameters
 * @returns Promise with paginated documents response
 */
export const getDocumentsPaginated = async (request: DocumentsRequest): Promise<PaginatedDocsResponse> => {
  const { requestEntry, release } = subscribeToPaginatedDocumentsRequest(request)

  try {
    return await requestEntry.promise
  } finally {
    release(false)
  }
}

export const getDocumentsPaginatedWithTimeout = (
  request: DocumentsRequest,
  timeoutMs: number = 30000,
  errorMsg: string = documentFetchTimeoutMessage
): Promise<PaginatedDocsResponse> => {
  const { requestEntry, release } = subscribeToPaginatedDocumentsRequest(request)

  return new Promise<PaginatedDocsResponse>((resolve, reject) => {
    let timedOut = false
    const timeoutId = setTimeout(() => {
      timedOut = true
      release(true)
      reject(new Error(errorMsg))
    }, timeoutMs)

    requestEntry.promise
      .then(response => {
        if (timedOut) {
          return
        }
        clearTimeout(timeoutId)
        release(false)
        resolve(response)
      })
      .catch(error => {
        if (timedOut) {
          return
        }
        clearTimeout(timeoutId)
        release(false)
        reject(error)
      })
  })
}
