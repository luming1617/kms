import { ComponentProps, ReactNode, useEffect, useMemo, useRef, memo, useState } from 'react' // Import useMemo
import { Message } from '@/api/lightrag'
import useTheme from '@/hooks/useTheme'
import { cn } from '@/lib/utils'

import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import rehypeReact from 'rehype-react'
import rehypeRaw from 'rehype-raw'
import rehypeSanitize from 'rehype-sanitize'
import remarkMath from 'remark-math'
import { remarkFootnotes } from '@/utils/remarkFootnotes'
import { chatMarkdownSanitizeSchema } from '@/utils/markdownSanitizeSchema'


import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { oneLight, oneDark } from 'react-syntax-highlighter/dist/cjs/styles/prism'

import { LoaderIcon, ChevronDownIcon, ClockIcon, ZapIcon } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import { useAiContentNoticeStore } from '@/stores/aiContentNotice'
import { shouldShowAiContentNotice } from '@/lib/aiContentNotice'

// KaTeX configuration options interface
interface KaTeXOptions {
  errorColor?: string;
  throwOnError?: boolean;
  displayMode?: boolean;
  strict?: boolean;
  trust?: boolean;
  errorCallback?: (error: string, latex: string) => void;
}

// MessageWithError moved to the retrieval types module so the UI-free query
// session controller does not depend on this rendering component; re-exported
// here for existing importers.
import type { MessageWithError } from '@/types/retrieval'
export type { MessageWithError } from '@/types/retrieval'

// Kept out of this file so tests can stub the load without mocking the
// `mermaid` package process-wide; see `mermaidLoader.ts`.
import { loadMermaid } from './mermaidLoader'


/**
 * Tables scroll INSIDE their own block. The message list scrolls vertically
 * only (see MessageList), so a table wider than the conversation column would
 * otherwise be clipped and unreachable on a narrow screen.
 */
const ScrollableTable = ({ children }: { children?: ReactNode }) => (
  <div className="my-2 max-w-full overflow-x-auto">
    <table>{children}</table>
  </div>
)

// Restore original component definition and export
export const ChatMessage = ({
  message,
  isTabActive = true,
  activeProgress = null,
  isQuerying = false
}: {
  message: MessageWithError
  isTabActive?: boolean
  activeProgress?: string | null
  // True while this message's query is still in flight (from submit until the
  // finally/stop handler). Drives the clock's spin so it animates for the whole
  // query, not just the thinking phase.
  isQuerying?: boolean
}) => {
  const { t } = useTranslation()
  const { theme } = useTheme()
  // Deployment-level switch (ENABLE_AI_CONTENT_NOTICE), read from the server at
  // boot. Both query entries render answers through this component, so gating
  // it here is what covers /webui and /workspace alike.
  const aiContentNoticeEnabled = useAiContentNoticeStore((state) => state.enabled)
  const [katexPlugin, setKatexPlugin] = useState<((options?: KaTeXOptions) => any) | null>(null)
  const [isThinkingExpanded, setIsThinkingExpanded] = useState<boolean>(false)

  // Directly use props passed from the parent.
  const { thinkingContent, displayContent, thinkingTime, responseTime, firstTokenTime, isThinking } = message

  // Reset expansion state when new thinking starts.
  // Render-time comparison avoids cascading renders from setState-in-useEffect.
  const [previousThinkingState, setPreviousThinkingState] = useState({
    isThinking,
    messageId: message.id
  })
  if (
    previousThinkingState.isThinking !== isThinking ||
    previousThinkingState.messageId !== message.id
  ) {
    setPreviousThinkingState({ isThinking, messageId: message.id })
    if (isThinking) {
      setIsThinkingExpanded(false)
    }
  }

  // The content to display is now non-ambiguous.
  const finalThinkingContent = thinkingContent
  // For user messages, displayContent will be undefined, so we fall back to content.
  // For assistant messages, we prefer displayContent but fallback to content for backward compatibility
  const finalDisplayContent = message.role === 'user'
    ? message.content
    : (displayContent !== undefined ? displayContent : (message.content || ''))

  // Load KaTeX rehype plugin dynamically
  // Note: KaTeX extensions (mhchem, copy-tex) are imported statically in main.tsx
  useEffect(() => {
    const loadKaTeX = async () => {
      try {
        const { default: rehypeKatex } = await import('rehype-katex');
        setKatexPlugin(() => rehypeKatex);
      } catch (error) {
        console.error('Failed to load KaTeX plugin:', error);
        setKatexPlugin(null);
      }
    };

    loadKaTeX();
  }, []);

  const mainMarkdownComponents = useMemo(() => ({
    code: (props: any) => {
      const { inline, className, children, ...restProps } = props;
      const match = /language-(\w+)/.exec(className || '');
      const language = match ? match[1] : undefined;

      // Handle math blocks ($$...$$) - provide better container and styling
      if (language === 'math' && !inline) {
        return (
          <div className="katex-display-wrapper my-4 overflow-x-auto">
            <div className="text-current">{children}</div>
          </div>
        );
      }

      // Handle inline math ($...$) - ensure proper inline display
      if (language === 'math' && inline) {
        return (
          <span className="katex-inline-wrapper">
            <span className="text-current">{children}</span>
          </span>
        );
      }

      // Handle all other code (inline and block)
      return (
        <CodeHighlight
          inline={inline}
          className={className}
          {...restProps}
          renderAsDiagram={message.mermaidRendered ?? false}
          messageRole={message.role}
        >
          {children}
        </CodeHighlight>
      );
    },
    p: ({ children }: { children?: ReactNode }) => <div className="my-2">{children}</div>,
    h1: ({ children }: { children?: ReactNode }) => <h1 className="text-xl font-bold mt-4 mb-2">{children}</h1>,
    h2: ({ children }: { children?: ReactNode }) => <h2 className="text-lg font-bold mt-4 mb-2">{children}</h2>,
    h3: ({ children }: { children?: ReactNode }) => <h3 className="text-base font-bold mt-3 mb-2">{children}</h3>,
    h4: ({ children }: { children?: ReactNode }) => <h4 className="text-base font-semibold mt-3 mb-2">{children}</h4>,
    ul: ({ children }: { children?: ReactNode }) => <ul className="list-disc pl-5 my-2">{children}</ul>,
    ol: ({ children }: { children?: ReactNode }) => <ol className="list-decimal pl-5 my-2">{children}</ol>,
    li: ({ children }: { children?: ReactNode }) => <li className="my-1">{children}</li>,
    table: ScrollableTable
  }), [message.mermaidRendered, message.role]);

  const thinkingMarkdownComponents = useMemo(() => ({
    code: (props: any) => (<CodeHighlight {...props} renderAsDiagram={message.mermaidRendered ?? false} messageRole={message.role} />),
    table: ScrollableTable
  }), [message.mermaidRendered, message.role]);

  // Whether the assistant has begun emitting visible answer text. Drives both
  // where the timing row is placed and whether retrieval progress is shown.
  const hasContent = !!finalDisplayContent && finalDisplayContent.trim() !== ''

  // AI-generated content notice (ENABLE_AI_CONTENT_NOTICE): a trailing item on
  // the meta row below the answer, never a line of its own. What may carry the
  // label is decided by the query session and travels on the message
  // (`aiGenerated`) — a context-only debug response is not generated, while a
  // stream that failed after emitting real answer text still is. It lives
  // outside the markdown and outside `message.content`, so it never reaches
  // the copy button, the retrieval history or the API response.
  const aiContentNotice = shouldShowAiContentNotice({
    enabled: aiContentNoticeEnabled,
    role: message.role,
    aiGenerated: message.aiGenerated,
    hasContent
  }) ? (
      <span className="italic" data-testid="ai-content-notice">
        {t('retrievePanel.chatMessage.aiContentNotice')}
      </span>
    ) : null

  // Response time (+ first-token time) row. While no answer text exists yet it
  // sits above the "Thinking..." hint (so the time stays put as the hint
  // appears below it); once content arrives it is relocated to the end of the
  // answer. Retrieval progress trails on the same line, but only before any
  // answer text is shown; the AI-content notice trails it only AFTER content
  // exists, so the two never share the line. `flex-wrap` keeps the notice from
  // pushing the row past a phone-width bubble.
  const timingRow =
    message.role === 'assistant' && typeof responseTime === 'number' ? (
      <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
        <span className="flex items-center gap-1 tabular-nums">
          <ClockIcon className={cn('size-3', isQuerying && 'animate-spin')} />
          {t('retrievePanel.chatMessage.responseTime', { time: responseTime.toFixed(1) })}
        </span>
        {typeof firstTokenTime === 'number' && (
          <span className="flex items-center gap-1 tabular-nums">
            <ZapIcon className="size-3" />
            {t('retrievePanel.chatMessage.firstTokenTime', { time: firstTokenTime.toFixed(1) })}
          </span>
        )}
        {!hasContent && activeProgress && (
          // Progress trails the time as a parenthesised note (no spinner — the
          // "Thinking..." hint above already carries one, so a second would be
          // redundant).
          <span className="text-muted-foreground/70">
            ({t(`retrievePanel.chatMessage.progress.${activeProgress}`, activeProgress)})
          </span>
        )}
        {aiContentNotice}
      </div>
    ) : null

  // The bubble shares its flex row with a fixed-width copy button (24px plus
  // an 8px gap), and its percentage width knows nothing about that. `min-w-0`
  // is therefore required, not cosmetic: without it the flex item's automatic
  // minimum size pins the bubble at 95% and the row overflows by ~32px on a
  // phone-width screen.
  return (
    <div
      className={`${
        message.role === 'user'
          ? 'max-w-[80%] bg-primary text-primary-foreground'
          : message.isError
            ? 'w-[95%] bg-red-100 text-red-600 dark:bg-red-950 dark:text-red-400'
            : 'w-[95%] bg-muted'
      } min-w-0 rounded-lg px-4 py-2`}
    >
      {/* Before any answer text: the timing row sits on top and the thinking
          hint appears beneath it, so the time doesn't jump when "Thinking..."
          shows up. Once content arrives, the row moves below the answer. */}
      {!hasContent && timingRow}
      {/* Thinking process display - only for assistant messages */}
      {/* Always render to prevent layout shift when switching tabs */}
      {message.role === 'assistant' && (isThinking || thinkingTime !== null) && (
        <div className={cn(
          'mb-2',
          // Reduce visual priority in inactive tabs while maintaining layout
          !isTabActive && 'opacity-50'
        )}>
          <div
            // Indent by 1rem ONLY while the timing row sits directly above this
            // line (i.e. no answer text yet): there the clock icon (size-3) +
            // gap-1 push the time label right by exactly 1rem, so the same
            // margin lines the two labels up. Once content arrives the timing
            // row moves below the answer, so the thinking line drops the indent
            // and aligns left with the answer instead. (The thinking spinner is
            // dropped — the timing row's clock already animates while thinking.)
            className={cn(
              'flex items-center text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 transition-colors duration-200 text-sm cursor-pointer select-none',
              !hasContent && 'ml-4'
            )}
            onClick={() => {
              // Allow expansion when there's thinking content, even during thinking process
              if (finalThinkingContent && finalThinkingContent.trim() !== '') {
                setIsThinkingExpanded(!isThinkingExpanded)
              }
            }}
          >
            {isThinking ? (
              <span>{t('retrievePanel.chatMessage.thinking')}</span>
            ) : (
              typeof thinkingTime === 'number' && <span>{t('retrievePanel.chatMessage.thinkingTime', { time: thinkingTime })}</span>
            )}
            {/* Show chevron when there's thinking content, even during thinking process */}
            {finalThinkingContent && finalThinkingContent.trim() !== '' && <ChevronDownIcon className={`ml-2 size-4 shrink-0 transition-transform ${isThinkingExpanded ? 'rotate-180' : ''}`} />}
          </div>
          {/* Show thinking content when expanded and content exists, even during thinking process */}
          {isThinkingExpanded && finalThinkingContent && finalThinkingContent.trim() !== '' && (
            <div className="mt-2 pl-4 border-l-2 border-primary/20 dark:border-primary/40 text-sm prose dark:prose-invert max-w-none break-words prose-p:my-1 prose-headings:my-2 [&_sup]:text-[0.75em] [&_sup]:align-[0.1em] [&_sup]:leading-[0] [&_sub]:text-[0.75em] [&_sub]:align-[-0.2em] [&_sub]:leading-[0] [&_mark]:bg-yellow-200 [&_mark]:dark:bg-yellow-800 [&_u]:underline [&_del]:line-through [&_ins]:underline [&_ins]:decoration-green-500 [&_.footnotes]:mt-6 [&_.footnotes]:pt-3 [&_.footnotes]:border-t [&_.footnotes]:border-border [&_.footnotes_ol]:text-xs [&_.footnotes_li]:my-0.5 [&_a[href^='#fn']]:text-primary [&_a[href^='#fn']]:no-underline [&_a[href^='#fn']]:hover:underline [&_a[href^='#fnref']]:text-primary [&_a[href^='#fnref']]:no-underline [&_a[href^='#fnref']]:hover:underline text-foreground">
              {isThinking && (
                <div className="mb-2 text-xs text-gray-400 dark:text-gray-300 italic">
                  {t('retrievePanel.chatMessage.thinkingInProgress', 'Thinking in progress...')}
                </div>
              )}
              <ReactMarkdown
                remarkPlugins={[remarkGfm, remarkFootnotes, remarkMath]}
                rehypePlugins={[
                  rehypeRaw,
                  // Thinking content is untrusted (derived from ingested
                  // documents); sanitize the raw HTML rehypeRaw just parsed
                  // before it can render (GHSA-xpjq-3w4w-w5wr).
                  [rehypeSanitize, chatMarkdownSanitizeSchema],
                  ...((katexPlugin && (message.latexRendered ?? true)) ? [[katexPlugin, {
                    errorColor: theme === 'dark' ? '#ef4444' : '#dc2626',
                    throwOnError: false,
                    displayMode: false,
                    strict: false,
                    trust: false,
                    // Add silent error handling to avoid console noise
                    errorCallback: (error: string, latex: string) => {
                      // Only show detailed errors in development environment
                      if (process.env.NODE_ENV === 'development') {
                        console.warn('KaTeX rendering error in thinking content:', error, 'for LaTeX:', latex);
                      }
                    }
                  }] as any] : []),
                  rehypeReact
                ]}
                skipHtml={false}
                components={thinkingMarkdownComponents}
              >
                {finalThinkingContent}
              </ReactMarkdown>
            </div>
          )}
        </div>
      )}
      {/* Main content display. Isolated in a memo'd component so the message's
          100ms stopwatch re-render (which only changes the timing row) does NOT
          re-run the markdown / syntax-highlight / KaTeX pipeline over the whole
          answer — it re-renders only when content/theme/latex/role change. */}
      {finalDisplayContent && (
        <MessageMarkdown
          content={finalDisplayContent}
          components={mainMarkdownComponents}
          katexPlugin={katexPlugin}
          theme={theme}
          latexRendered={message.latexRendered ?? true}
          role={message.role}
        />
      )}
      {/* Once answer text has started, the timing row follows at the end of
          the answer (progress is already hidden by then). */}
      {hasContent && timingRow}
      {/* User-terminated hint - response may be incomplete */}
      {message.isAborted && (
        <div className="mt-1 text-xs italic text-muted-foreground">
          {t('retrievePanel.retrieval.userTerminated')}
        </div>
      )}
      {/* Answers restored from the retrieval history carry no timing, so the
          notice would have nowhere to sit. It then gets the same row on its
          own rather than being dropped. */}
      {!timingRow && aiContentNotice && (
        <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
          {aiContentNotice}
        </div>
      )}
      {/* Loading indicator — only in the active tab, and only as a fallback when
          the timing row isn't already on screen. During a query the timing row
          shows a live stopwatch + retrieval progress, so this bare spinner would
          be a redundant second animation; suppress it whenever timingRow renders
          (i.e. an assistant message with a response time). */}
      {isTabActive && !message.isAborted && (() => {
        // More comprehensive loading state check
        const hasVisibleContent = finalDisplayContent && finalDisplayContent.trim() !== '';
        const isLoadingState = !hasVisibleContent && !isThinking && !thinkingTime && !timingRow;
        return isLoadingState && <LoaderIcon className="animate-spin duration-2000" />
      })()}
    </div>
  )
}

// Main answer markdown, isolated behind memo so the 100ms stopwatch re-render
// of a message (which only touches the timing row) does NOT re-run the markdown
// / syntax-highlight / KaTeX pipeline over the whole answer. All props are
// stable across timer ticks, so this re-renders only when the content (or
// theme / latex-readiness / role) actually changes.
const MessageMarkdown = memo(function MessageMarkdown({
  content,
  components,
  katexPlugin,
  theme,
  latexRendered,
  role
}: {
  content: string
  components: ComponentProps<typeof ReactMarkdown>['components']
  katexPlugin: ((options?: KaTeXOptions) => any) | null
  theme: string
  latexRendered: boolean
  role: Message['role']
}) {
  return (
    <div className="relative">
      <div className={`prose dark:prose-invert max-w-none text-sm break-words prose-headings:mt-4 prose-headings:mb-2 prose-p:my-2 prose-ul:my-2 prose-ol:my-2 prose-li:my-1 [&_.katex]:text-current [&_.katex-display]:my-4 [&_.katex-display]:max-w-full [&_.katex-display_>.base]:overflow-x-auto [&_sup]:text-[0.75em] [&_sup]:align-[0.1em] [&_sup]:leading-[0] [&_sub]:text-[0.75em] [&_sub]:align-[-0.2em] [&_sub]:leading-[0] [&_mark]:bg-yellow-200 [&_mark]:dark:bg-yellow-800 [&_u]:underline [&_del]:line-through [&_ins]:underline [&_ins]:decoration-green-500 [&_.footnotes]:mt-8 [&_.footnotes]:pt-4 [&_.footnotes]:border-t [&_.footnotes_ol]:text-sm [&_.footnotes_li]:my-1 ${
        role === 'user'
          ? 'text-primary-foreground prose-inherit-color'
          : 'text-foreground'
      } ${
        role === 'user'
          ? '[&_.footnotes]:border-primary-foreground/30 [&_a[href^="#fn"]]:text-primary-foreground [&_a[href^="#fn"]]:no-underline [&_a[href^="#fn"]]:hover:underline [&_a[href^="#fnref"]]:text-primary-foreground [&_a[href^="#fnref"]]:no-underline [&_a[href^="#fnref"]]:hover:underline'
          : '[&_.footnotes]:border-border [&_a[href^="#fn"]]:text-primary [&_a[href^="#fn"]]:no-underline [&_a[href^="#fn"]]:hover:underline [&_a[href^="#fnref"]]:text-primary [&_a[href^="#fnref"]]:no-underline [&_a[href^="#fnref"]]:hover:underline'
      }`}>
        <ReactMarkdown
          remarkPlugins={[remarkGfm, remarkFootnotes, remarkMath]}
          rehypePlugins={[
            rehypeRaw,
            // Answer content is untrusted (derived from ingested documents);
            // sanitize the raw HTML rehypeRaw just parsed before it can render
            // (GHSA-xpjq-3w4w-w5wr).
            [rehypeSanitize, chatMarkdownSanitizeSchema],
            ...((katexPlugin && latexRendered) ? [[
              katexPlugin,
              {
                errorColor: theme === 'dark' ? '#ef4444' : '#dc2626',
                throwOnError: false,
                displayMode: false,
                strict: false,
                trust: false,
                // Add silent error handling to avoid console noise
                errorCallback: (error: string, latex: string) => {
                  // Only show detailed errors in development environment
                  if (process.env.NODE_ENV === 'development') {
                    console.warn('KaTeX rendering error in main content:', error, 'for LaTeX:', latex);
                  }
                }
              }
            ] as any] : []),
            rehypeReact
          ]}
          skipHtml={false}
          components={components}
        >
          {content}
        </ReactMarkdown>
      </div>
    </div>
  )
})

interface CodeHighlightProps {
  inline?: boolean
  className?: string
  children?: ReactNode
  renderAsDiagram?: boolean // Flag to indicate if rendering as diagram should be attempted
  messageRole?: 'user' | 'assistant' // Message role for context-aware styling
}



// Check if it is a large JSON
const isLargeJson = (language: string | undefined, content: string | undefined): boolean => {
  if (!content || language !== 'json') return false;
  return content.length > 5000; // JSON larger than 5KB is considered large JSON
};

// Memoize the CodeHighlight component
const CodeHighlight = memo(({ inline, className, children, renderAsDiagram = false, messageRole, ...props }: CodeHighlightProps) => {
  const { theme } = useTheme();
  const [hasRendered, setHasRendered] = useState(false); // State to track successful render
  const match = className?.match(/language-(\w+)/);
  const language = match ? match[1] : undefined;
  const mermaidRef = useRef<HTMLDivElement>(null);
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null); // Use ReturnType for better typing

  // Get the content string, check if it is a large JSON
  const contentStr = String(children || '').replace(/\n$/, '');
  const isLargeJsonBlock = isLargeJson(language, contentStr);

  // Handle Mermaid rendering with debounce
  useEffect(() => {
    // Effect should run when renderAsDiagram becomes true or hasRendered changes.
    // The actual rendering logic inside checks language and hasRendered state.
    if (renderAsDiagram && !hasRendered && language === 'mermaid' && mermaidRef.current) {
      const container = mermaidRef.current; // Capture ref value

      // Clear previous timer if dependencies change before timeout (e.g., renderAsDiagram flips quickly)
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }

      debounceTimerRef.current = setTimeout(async () => {
        if (!container) return; // Container might have unmounted

        // Double check hasRendered state inside timeout, in case it changed rapidly
        if (hasRendered) return;

        // Dynamic import: mermaid stays out of both entries' first-load
        // closure and is fetched only when a diagram is actually rendered.
        let mermaid: Awaited<ReturnType<typeof loadMermaid>>;
        try {
          mermaid = await loadMermaid();
        } catch (loadError) {
          // The renderer itself could not be fetched — a deploy invalidated
          // the hashed chunk mid-session, an offline tab, a flaky network.
          //
          // This MUST write something visible, like the two render-failure
          // paths below. Nothing has been put in the container yet (the
          // loading indicator is set only after this await), the effect's
          // dependencies cannot change again once the message settles, so
          // nothing retries, and the plain-text fallback branch in the
          // render body only runs while `renderAsDiagram` is false. A bare
          // return therefore leaves a permanently blank gap where a diagram
          // belongs, with the source unreachable too.
          console.error('Failed to load mermaid:', loadError);
          if (mermaidRef.current === container) {
            const errorMessage =
              loadError instanceof Error ? loadError.message : String(loadError);
            const fallbackPre = document.createElement('pre');
            fallbackPre.className = 'text-red-500 text-xs whitespace-pre-wrap break-words';
            fallbackPre.textContent = `Mermaid renderer failed to load: ${errorMessage}\n\nContent:\n${String(children).replace(/\n$/, '').trim()}`;
            container.innerHTML = '';
            container.appendChild(fallbackPre);
          }
          return;
        }
        if (mermaidRef.current !== container || hasRendered) return;

        try {
          // Initialize mermaid config
          mermaid.initialize({
            startOnLoad: false,
            theme: theme === 'dark' ? 'dark' : 'default',
            // 'loose' disables mermaid's built-in DOMPurify output sanitization
            // and enables HTML labels / click JS; since the rendered SVG is
            // injected via innerHTML below, an attacker-controlled ```mermaid```
            // block in answer content would be a script sink. 'strict' makes
            // mermaid sanitize its output and disable interaction
            // (GHSA-xpjq-3w4w-w5wr).
            securityLevel: 'strict',
            suppressErrorRendering: true,
          });

          // Show loading indicator
          container.innerHTML = '<div class="flex justify-center items-center p-4"><svg class="animate-spin h-5 w-5 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg></div>';

          // Preprocess mermaid content
          const rawContent = String(children).replace(/\n$/, '').trim();

          // Heuristic check for potentially complete graph definition
          const looksPotentiallyComplete = rawContent.length > 10 && (
            rawContent.startsWith('graph') ||
            rawContent.startsWith('sequenceDiagram') ||
            rawContent.startsWith('classDiagram') ||
            rawContent.startsWith('stateDiagram') ||
            rawContent.startsWith('gantt') ||
            rawContent.startsWith('pie') ||
            rawContent.startsWith('flowchart') ||
            rawContent.startsWith('erDiagram')
          );

          if (!looksPotentiallyComplete) {
            console.log('Mermaid content might be incomplete, skipping render attempt:', rawContent);
            // Optionally keep loading indicator or show a message
            // container.innerHTML = '<p class="text-sm text-muted-foreground">Waiting for complete diagram...</p>';
            return;
          }

          const processedContent = rawContent
            .split('\n')
            .map(line => {
              const trimmedLine = line.trim();
              if (trimmedLine.startsWith('subgraph')) {
                const parts = trimmedLine.split(' ');
                if (parts.length > 1) {
                  const title = parts.slice(1).join(' ').replace(/["']/g, '');
                  return `subgraph "${title}"`;
                }
              }
              return trimmedLine;
            })
            .filter(line => !line.trim().startsWith('linkStyle'))
            .join('\n');

          const mermaidId = `mermaid-${Date.now()}`;
          mermaid.render(mermaidId, processedContent)
            .then(({ svg, bindFunctions }) => {
              // Check ref and hasRendered state again inside async callback
              if (mermaidRef.current === container && !hasRendered) {
                container.innerHTML = svg;
                setHasRendered(true); // Mark as rendered successfully
                if (bindFunctions) {
                  try {
                    bindFunctions(container);
                  } catch (bindError) {
                    console.error('Mermaid bindFunctions error:', bindError);
                    container.innerHTML += '<p class="text-orange-500 text-xs">Diagram interactions might be limited.</p>';
                  }
                }
              } else if (mermaidRef.current !== container) {
                console.log('Mermaid container changed before rendering completed.');
              }
            })
            .catch(error => {
              console.error('Mermaid rendering promise error (debounced):', error);
              console.error('Failed content (debounced):', processedContent);
              if (mermaidRef.current === container) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                const errorPre = document.createElement('pre');
                errorPre.className = 'text-red-500 text-xs whitespace-pre-wrap break-words';
                errorPre.textContent = `Mermaid diagram error: ${errorMessage}\n\nContent:\n${processedContent}`;
                container.innerHTML = '';
                container.appendChild(errorPre);
              }
            });

        } catch (error) {
          console.error('Mermaid synchronous error (debounced):', error);
          console.error('Failed content (debounced):', String(children));
          if (mermaidRef.current === container) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            const errorPre = document.createElement('pre');
            errorPre.className = 'text-red-500 text-xs whitespace-pre-wrap break-words';
            errorPre.textContent = `Mermaid diagram setup error: ${errorMessage}`;
            container.innerHTML = '';
            container.appendChild(errorPre);
          }
        }
      }, 300); // Debounce delay
    }

    // Cleanup function to clear the timer on unmount or before re-running effect
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  // Dependencies: renderAsDiagram ensures effect runs when diagram should be shown.
  // Dependencies include all values used inside the effect to satisfy exhaustive-deps.
  // The !hasRendered check prevents re-execution of render logic after success.
  }, [renderAsDiagram, hasRendered, language, children, theme]); // Add children and theme back

  // For large JSON, skip syntax highlighting completely and use a simple pre tag
  if (isLargeJsonBlock) {
    return (
      <pre className="whitespace-pre-wrap break-words bg-muted p-4 rounded-md overflow-x-auto text-sm font-mono">
        {contentStr}
      </pre>
    );
  }

  // Render based on language type
  // If it's a mermaid language block and rendering as diagram is not requested (e.g., incomplete stream), display as plain text
  if (language === 'mermaid' && !renderAsDiagram) {
    return (
      <SyntaxHighlighter
        style={theme === 'dark' ? oneDark : oneLight}
        PreTag="div"
        language="text" // Use text as language to avoid syntax highlighting errors
        {...props}
      >
        {contentStr}
      </SyntaxHighlighter>
    );
  }

  // If it's a mermaid language block and the message is complete, render as diagram
  if (language === 'mermaid') {
    // Container for Mermaid diagram
    return <div className="mermaid-diagram-container my-4 overflow-x-auto" ref={mermaidRef}></div>;
  }


  // ReactMarkdown determines inline vs block based on markdown syntax
  // Inline code: `code` (no className with language)
  // Block code: ```language (has className like "language-js")
  // If there's no language className and no explicit inline prop, it's likely inline code
  const isInline = inline ?? !className?.startsWith('language-');

  // Generate dynamic inline code styles based on message role and theme
  const getInlineCodeStyles = () => {
    if (messageRole === 'user') {
      // User messages have dark background (bg-primary), need light inline code
      return theme === 'dark'
        ? 'bg-primary-foreground/20 text-primary-foreground border border-primary-foreground/30'
        : 'bg-primary-foreground/20 text-primary-foreground border border-primary-foreground/30';
    } else {
      // Assistant messages have light background (bg-muted), need contrasting inline code
      return theme === 'dark'
        ? 'bg-muted-foreground/20 text-muted-foreground border border-muted-foreground/30'
        : 'bg-slate-200 text-slate-800 border border-slate-300';
    }
  };

  // Handle non-Mermaid code blocks
  return !isInline ? (
    <SyntaxHighlighter
      style={theme === 'dark' ? oneDark : oneLight}
      PreTag="div"
      language={language}
      {...props}
    >
      {contentStr}
    </SyntaxHighlighter>
  ) : (
    // Handle inline code with context-aware styling
    <code
      className={cn(
        className,
        'mx-1 rounded-sm px-1 py-0.5 font-mono text-sm',
        getInlineCodeStyles()
      )}
      {...props}
    >
      {children}
    </code>
  );
});

// Assign display name for React DevTools
CodeHighlight.displayName = 'CodeHighlight';
